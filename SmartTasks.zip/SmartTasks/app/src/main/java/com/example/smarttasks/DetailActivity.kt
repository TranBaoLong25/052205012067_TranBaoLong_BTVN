package com.example.smarttasks

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.smarttasks.databinding.ActivityDetailBinding
import com.example.smarttasks.model.Task
import com.example.smarttasks.network.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private var task: Task? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        task = intent.getParcelableExtra("task")
        if (task == null) {
            finish()
            return
        }

        displayTask(task!!)
        binding.btnDelete.setOnClickListener { confirmDelete(task!!.id) }
    }

    private fun displayTask(task: Task) {
        binding.tvTitle.text = task.title
        binding.tvDesc.text = task.description ?: ""
        binding.tvCategory.text = task.category ?: ""
        binding.tvStatus.text = task.status ?: ""
        binding.tvPriority.text = task.priority ?: ""
        binding.tvSubtasks.text = task.subtasks.joinToString("\n")
        binding.tvAttachments.text = task.attachments.joinToString("\n")
    }

    private fun confirmDelete(id: Int) {
        AlertDialog.Builder(this)
            .setTitle("Xóa công việc")
            .setMessage("Bạn có chắc muốn xóa công việc này?")
            .setPositiveButton("Xóa") { _, _ -> deleteTask(id) }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun deleteTask(id: Int) {
        binding.progress.visibility = android.view.View.VISIBLE
        ApiClient.service.deleteTask(id).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                binding.progress.visibility = android.view.View.GONE
                if (response.isSuccessful) {
                    Toast.makeText(this@DetailActivity, "Xóa thành công", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@DetailActivity, "Xóa thất bại", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                binding.progress.visibility = android.view.View.GONE
                Toast.makeText(this@DetailActivity, "Lỗi mạng: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
