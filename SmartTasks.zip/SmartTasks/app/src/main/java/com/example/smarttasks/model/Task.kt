package com.example.smarttasks.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Task(
    val id: Int,
    val title: String,
    val description: String?,
    val status: String?,
    val priority: String?,
    val category: String?,
    val dueDate: String?,
    val subtasks: List<String> = emptyList(),
    val attachments: List<String> = emptyList()
) : Parcelable
