package com.example.smarttasks

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.smarttasks.adapter.TaskAdapter
import com.example.smarttasks.databinding.ActivityMainBinding
import com.example.smarttasks.model.Task
import com.example.smarttasks.network.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = TaskAdapter(emptyList()) { task -> openDetail(task) }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.fabAdd.setOnClickListener {
            Toast.makeText(this, "Function add not implemented", Toast.LENGTH_SHORT).show()
        }

        loadTasks()
    }

    private fun loadTasks() {
        binding.progress.visibility = View.VISIBLE
        ApiClient.service.getTasks().enqueue(object : Callback<List<Task>> {
            override fun onResponse(call: Call<List<Task>>, response: Response<List<Task>>) {
                binding.progress.visibility = View.GONE
                if (response.isSuccessful) {
                    val list = response.body() ?: emptyList()
                    if (list.isEmpty()) showEmpty() else showList(list)
                } else {
                    Toast.makeText(this@MainActivity, "Server error", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<Task>>, t: Throwable) {
                binding.progress.visibility = View.GONE
                Toast.makeText(this@MainActivity, "Network error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
                showEmpty()
            }
        })
    }

    private fun showEmpty() {
        binding.recycler.visibility = View.GONE
        binding.emptyView.visibility = View.VISIBLE
    }

    private fun showList(list: List<Task>) {
        binding.recycler.visibility = View.VISIBLE
        binding.emptyView.visibility = View.GONE
        adapter.update(list)
    }

    private fun openDetail(task: Task) {
        val i = Intent(this, DetailActivity::class.java)
        i.putExtra("task", task)
        startActivity(i)
    }

    override fun onResume() {
        super.onResume()
        loadTasks() // refresh when return
    }
}
