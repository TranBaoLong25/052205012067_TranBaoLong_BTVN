package com.example.smarttasks.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.smarttasks.databinding.ItemTaskBinding
import com.example.smarttasks.model.Task

class TaskAdapter(private var items: List<Task>, private val listener: (Task) -> Unit)
    : RecyclerView.Adapter<TaskAdapter.VH>() {

    inner class VH(private val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(task: Task) {
            binding.tvTitle.text = task.title
            binding.tvStatus.text = task.status ?: ""
            binding.tvDesc.text = task.description ?: ""
            binding.root.setOnClickListener { listener(task) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemTaskBinding.inflate(inflater, parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    fun update(newList: List<Task>) {
        items = newList
        notifyDataSetChanged()
    }
}
