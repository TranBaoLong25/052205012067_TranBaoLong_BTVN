SmartTasks - Starter Android (Kotlin) project
------------------------------------------------
Features included:
- List screen calling GET /tasks
- Empty view when list is empty
- Click item -> Detail screen (uses Parcelable task by default)
- Detail screen can DELETE /task/{id}
- Retrofit + Gson + OkHttp + ViewBinding

Notes:
- gradle wrapper binary (gradle/wrapper/gradle-wrapper.jar) is NOT included here.
  If Android Studio complains about missing wrapper, open the project in Android Studio
  and let it download/set up the Gradle wrapper, or run:
     gradle wrapper --gradle-version 8.4.1
- Base URL set to: https://amock.io/api/researchUTH/
- If API returns different fields, update model/Task.kt accordingly.

How to open:
1) Open this folder in Android Studio.
2) Sync Gradle. If prompted to create or download Gradle wrapper, accept.
3) Build & Run on emulator/device.
